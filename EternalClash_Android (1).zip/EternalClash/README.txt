ETERNAL CLASH - Android build kit
=================================

What's inside
- www/      The whole game (open www/index.html in a browser to play it on a computer).
- android/  A small Android app that runs the game full screen in landscape.
- build-apk.yml  The GitHub workflow that turns this into an APK.

Build the APK on GitHub (works from a phone browser, no PC needed)
1. Create a new repository on github.com (for example "eternal-clash").
2. Add file > Upload files > upload EternalClash_Android.zip (this zip, unchanged). Commit.
3. Add file > Create new file. Name it exactly:  .github/workflows/build-apk.yml
   Paste the contents of build-apk.yml, then commit.
4. Open the Actions tab > "Build Eternal Clash APK" > Run workflow.
   (It also runs by itself every time you upload a new EternalClash_Android.zip.)
5. After about 5 minutes, open Releases: a new release "Eternal Clash v1.0.N" has the APK attached.
   Download it on your phone and install (allow "Install unknown apps" for your browser).

Realistic 3D heroes (your own models and animations)
The built-in heroes are simple models made in code. To get realistic, MLBB-style heroes, give the game real
3D models. Each hero can have its own model and its own animations (idle, run, attacks, Skill 1, Skill 2,
Ultimate, death, victory, recall). The same model is used on the Heroes screen, in Battle Prep and in matches.

Make a model (free tools, work from a phone browser):
1. Meshy (meshy.ai) or Tripo (tripo3d.ai): Image to 3D, upload the hero's full-body picture.
2. Rig it (humanoid / T-pose), then add animations: Idle, Run, an Attack, Spell or Cast moves,
   Death and Victory.
3. Download each as .glb (turn off Draco compression; keep it under 100k triangles).

Option A - on one phone: open the game > Heroes > pick the hero > 3D Model > Import model, and select all
the .glb files at once. Use "Add animations" later for more moves. Name animation files after the move
("Run", "Attack", "Skill 1", "Skill 2", "Ultimate", "Death", "Victory") and the game sets them up by itself,
or pick which move plays when in the same panel. Imported models stay on that phone.

Option B - built into the APK for everyone: in your GitHub repository create a folder named "models" and
upload the files there, named after the hero:
    Nyxara.glb               (the model)
    Nyxara - Run.glb         (an animation)
    Nyxara - Skill 1.glb
    Nyxara - Ultimate.glb
The next build adds them to the app automatically (the workflow builds again when you upload to models/).

Models without a skeleton are rigged automatically (best in a T-pose or A-pose). Rigged models without
animations move with the built-in animations.

Notes
- Every build is signed with android/app/eternalclash.p12 so updates install over the old version.
  Before publishing on Google Play, make your own private upload key and keep it secret.
- Built-in heroes are 3D models made in code (skinned skeleton, toon shading) with run, attack, skill, death
  and display animations. Replace any of them with a real 3D model as described above.
- Skill effects use a glow pass (Settings > Glow effects) and element-themed particles. Graphics: Low, Medium,
  High or Ultra in Settings.
- The app serves the game from https://appassets.androidplatform.net inside the APK, so hero art and saves work offline.
- Matches are offline against AI. Online multiplayer needs a game server, which this kit does not include.
- Progress (rank, skins, currencies) is saved on the device.
